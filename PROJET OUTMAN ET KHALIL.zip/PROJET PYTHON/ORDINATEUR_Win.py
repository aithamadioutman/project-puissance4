from customtkinter import*
from PIL import Image
import subprocess


winner_dialog = CTk()
winner_dialog.title("Game Over")
winner_dialog.geometry("500x500")

    
    # Load images
winner_image = CTkImage(light_image=Image.open('lose.png'), dark_image=Image.open('lose.png'), size=(300, 150))
logout_image = CTkImage(dark_image=Image.open('logout.png'), light_image=Image.open('logout.png'))

    # Label displaying winner image
label = CTkLabel(winner_dialog, text="", image=winner_image)
label.pack(pady=50)


def replay():
    subprocess.run(["python", "connect.py"])


im_rep=Image.open("replay.png")
    # Replay button
bu1 = CTkButton(
    master=winner_dialog,
    text="REJOUER",
    corner_radius=32,
    fg_color="#C850C0",
    hover_color="#4158D0",
    image=CTkImage(dark_image=im_rep, light_image=im_rep),
    command=replay

    )
bu1.place(x=200, y=260)

    # Exit button
bu2 = CTkButton(
    master=winner_dialog,
    text="EXIT",
    corner_radius=32,
    fg_color="#C850C0",
    hover_color="#4158D0",
        #image=logout_image,
    command=winner_dialog.destroy
    )
bu2.place(x=200, y=300)
label2=CTkLabel(
    master=winner_dialog,
    text="Vous Avez perdu",
    font=("Helvetica",18),

)
label2.place(x=170, y=200)

winner_dialog.mainloop()
