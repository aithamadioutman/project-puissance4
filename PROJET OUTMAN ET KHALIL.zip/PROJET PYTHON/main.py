from customtkinter import *
from PIL import Image

import subprocess

root = CTk()
root.geometry("1900x1080")

def execute_connect_codeb():
    """
@brief Creates a Tkinter image from the specified images and sets it in a label.

This function creates a Tkinter image from the specified light and dark images and sets it in a label.

@param light_image The image to be displayed in light mode.
@param dark_image The image to be displayed in dark mode.
@param size The size of the image (width, height).
@return The Tkinter image.
"""
    subprocess.run(["python", "connect.py"])

my_image = CTkImage( light_image=Image.open('LOGY.jpeg'), dark_image=Image.open('LOGY.jpeg'), size=(400, 400))
my_label = CTkLabel(root, text="", image=my_image)
my_label.place(x=550, y=100)

image5 = Image.open("logout.png")
im6 = Image.open("arrow.png")

clear_button = CTkButton(root, corner_radius=10, fg_color="#C850C0", hover_color="#4158D0",
                         font=("HALVETICA", 14), text=" START", image=CTkImage(dark_image=im6, light_image=im6),
                         command=execute_connect_codeb)
clear_button.place(x=670, y=600)

undo_button = CTkButton(root, corner_radius=10, fg_color="#C850C0", hover_color="#4158D0",
                        font=("HALVETICA", 14), text="EXIT", image=CTkImage(dark_image=image5, light_image=image5),
                        command=root.destroy)
undo_button.place(x=670, y=650)

root.mainloop()
