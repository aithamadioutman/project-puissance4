import tkinter as tk
import numpy as np
import random
import math
from customtkinter import *
from PIL import Image

import subprocess

BLUE = "#964B00"
BLACK = "#000000"
RED = "#FF0000"
YELLOW = "#FFFF00"

ROW_COUNT = 6
COLUMN_COUNT = 7

PLAYER = 0
AI = 1

EMPTY = 0
PLAYER_PIECE = 1
AI_PIECE = 2

WINDOW_LENGTH = 4

move_history = []

def create_board(rows, cols):
    """
@brief Drops a game piece into the specified column of the game board.

@param board The game board.
@param row The row where the piece is dropped.
@param col The column where the piece is dropped.
@param piece The player or AI piece to be dropped.
"""
    board = []
    for _ in range(rows):
        row = [0] * cols
        board.append(row)
    return board

def drop_piece(board, row, col, piece):
    """
@brief Checks if a location in the specified column is a valid move.

@param board The game board.
@param col The column to check for validity.
@return True if the move is valid, False otherwise.
"""
    board[row][col] = piece

def is_valid_location(board, col):
    """
@brief Gets the next open row in the specified column.

@param board The game board.
@param col The column to find the next open row.
@return The row index of the next open position.
"""
    return board[len(board) - 1][col] == 0

def get_next_open_row(board, col):
    """
@brief Checks if a move in the specified column results in a winning move.

@param board The game board.
@param piece The player or AI piece to check for a winning move.
@param consecutive_pieces The number of consecutive pieces required for a win.
@return True if the move results in a winning move, False otherwise.
"""
    for r in range(len(board)):
        if board[r][col] == 0:
            return r

def winning_move(board, piece, consecutive_pieces):
    """
@brief Evaluates a window of pieces on the game board and assigns a score.

@param window The window of pieces to evaluate.
@param piece The player or AI piece for scoring.
@return The score assigned to the window.
"""
    # Check horizontal
    for r in range(len(board)):
        for c in range(len(board[0]) - consecutive_pieces + 1):
            count = 0
            for i in range(consecutive_pieces):
                if board[r][c + i] == piece:
                    count += 1
            if count == consecutive_pieces:
                return True

    # Check vertical
    for c in range(len(board[0])):
        for r in range(len(board) - consecutive_pieces + 1):
            count = 0
            for i in range(consecutive_pieces):
                if board[r + i][c] == piece:
                    count += 1
            if count == consecutive_pieces:
                return True

    # Check diagonals (top-left to bottom-right)
    for r in range(len(board) - consecutive_pieces + 1):
        for c in range(len(board[0]) - consecutive_pieces + 1):
            count = 0
            for i in range(consecutive_pieces):
                if board[r + i][c + i] == piece:
                    count += 1
            if count == consecutive_pieces:
                return True

    # Check diagonals (bottom-left to top-right)
    for r in range(consecutive_pieces - 1, len(board)):
        for c in range(len(board[0]) - consecutive_pieces + 1):
            count = 0
            for i in range(consecutive_pieces):
                if board[r - i][c + i] == piece:
                    count += 1
            if count == consecutive_pieces:
                return True

    return False

def evaluate_window(window, piece):
    """
@brief Scores the current position of the game board for the specified player or AI.

@param board The game board.
@param piece The player or AI piece to score.
@return The score of the current position for the specified player or AI.
"""
    score = 0
    opp_piece = PLAYER_PIECE if piece == AI_PIECE else AI_PIECE

    count_piece = window.count(piece)
    count_empty = window.count(EMPTY)
    count_opp_piece = window.count(opp_piece)

    if count_piece == 4:
        score += 100
    elif count_piece == 3 and count_empty == 1:
        score += 5
    elif count_piece == 2 and count_empty == 2:
        score += 2

    if count_opp_piece == 3 and count_empty == 1:
        score -= 4

    return score

def score_position(board, piece):
    """
@brief Checks if the current game state is a terminal node.

@param board The game board.
@return True if the game state is a terminal node, False otherwise.
"""
    score = 0

    center_column = len(board[0]) // 2
    center_count = board[:, center_column].tolist().count(piece)
    score += center_count * 3

    for r in range(len(board)):
        row_array = board[r, :].tolist()
        for c in range(len(board[0]) - WINDOW_LENGTH + 1):
            window = row_array[c:c+WINDOW_LENGTH]
            score += evaluate_window(window, piece)

    for c in range(len(board[0])):
        col_array = board[:, c].tolist()
        for r in range(len(board) - WINDOW_LENGTH + 1):
            window = col_array[r:r+WINDOW_LENGTH]
            score += evaluate_window(window, piece)

    for r in range(len(board) - WINDOW_LENGTH + 1):
        for c in range(len(board[0]) - WINDOW_LENGTH + 1):
            window = [board[r+i][c+i] for i in range(WINDOW_LENGTH)]
            score += evaluate_window(window, piece)

    for r in range(WINDOW_LENGTH - 1, len(board)):
        for c in range(len(board[0]) - WINDOW_LENGTH + 1):
            window = [board[r-i][c+i] for i in range(WINDOW_LENGTH)]
            score += evaluate_window(window, piece)

    return score

def is_terminal_node(board):
    """
@brief Implements the minimax algorithm to determine the best move for the AI.

@param board The game board.
@param depth The depth of the search in the minimax algorithm.
@param alpha The alpha value for alpha-beta pruning.
@param beta The beta value for alpha-beta pruning.
@param maximizingPlayer True if the AI is maximizing, False if it's the opponent's turn.
@return The column and corresponding score of the best move.
"""
    return winning_move(board, PLAYER_PIECE, WINDOW_LENGTH) or \
           winning_move(board, AI_PIECE, WINDOW_LENGTH) or \
           len(get_valid_locations(board)) == 0

def minimax(board, depth, alpha, beta, maximizingPlayer):
    """
@brief Gets a list of valid locations (columns) for the current game state.

@param board The game board.
@return A list of valid column locations.
"""
    valid_locations = get_valid_locations(board)
    is_terminal = is_terminal_node(board)
    
    if depth == 0 or is_terminal:
        if is_terminal:
            if winning_move(board, AI_PIECE, WINDOW_LENGTH):
                return None, 100000000000000
            elif winning_move(board, PLAYER_PIECE, WINDOW_LENGTH):
                return None, -10000000000000
        return None, 0 if is_terminal else score_position(board, AI_PIECE)
    
    if maximizingPlayer:
        value = -math.inf
        column = random.choice(valid_locations)
        for col in valid_locations:
            row = get_next_open_row(board, col)
            b_copy = np.copy(board)
            drop_piece(b_copy, row, col, AI_PIECE)
            new_score = minimax(b_copy, depth-1, alpha, beta, False)[1]
            if new_score > value:
                value = new_score
                column = col
            alpha = max(alpha, value)
            if alpha >= beta:
                break
        return column, value
    else:
        value = math.inf
        column = random.choice(valid_locations)
        for col in valid_locations:
            row = get_next_open_row(board, col)
            b_copy = np.copy(board)
            drop_piece(b_copy, row, col, PLAYER_PIECE)
            new_score = minimax(b_copy, depth-1, alpha, beta, True)[1]
            if new_score < value:
                value = new_score
                column = col
            beta = min(beta, value)
            if alpha >= beta:
                break
        return column, value

def get_valid_locations(board):
    """
@brief Draws the current state of the game board on the canvas.
"""
    valid_locations = []
    for col in range(len(board[0])):
        if is_valid_location(board, col):
            valid_locations.append(col)
    return valid_locations

def draw_board():
    """
@brief Handles the mouse motion event when hovering over the game board.

@param event The mouse motion event.
"""
    global root  # Indicate that root is a global variable

    canvas.delete("all")

    for c in range(len(board[0])):
        for r in range(len(board)):
            canvas.create_rectangle(c * SQUARESIZE, r * SQUARESIZE + SQUARESIZE,
                                    (c + 1) * SQUARESIZE, (r + 1) * SQUARESIZE + SQUARESIZE,
                                    fill=BLUE, outline='black')
            canvas.create_oval(c * SQUARESIZE, r * SQUARESIZE + SQUARESIZE,
                                (c + 1) * SQUARESIZE, (r + 1) * SQUARESIZE + SQUARESIZE,
                                fill=BLACK)

    for c in range(len(board[0])):
        for r in range(len(board)):
            if board[r][c] == PLAYER_PIECE:
                canvas.create_oval(c * SQUARESIZE, (len(board) - 1 - r) * SQUARESIZE + SQUARESIZE,
                                    (c + 1) * SQUARESIZE, (len(board) - r) * SQUARESIZE + SQUARESIZE,
                                    fill=RED)
            elif board[r][c] == AI_PIECE:
                canvas.create_oval(c * SQUARESIZE, (len(board) - 1 - r) * SQUARESIZE + SQUARESIZE,
                                    (c + 1) * SQUARESIZE, (len(board) - r) * SQUARESIZE + SQUARESIZE,
                                    fill=YELLOW)

    root.update_idletasks()
    root.update()

def on_motion(event):
    """
@brief Handles the mouse click event when a player makes a move.

@param event The mouse click event.
"""
    canvas.delete("preview_piece")
    posx = event.x
    if turn == PLAYER:
        canvas.create_arc(posx - RADIUS, SQUARESIZE / 2 - RADIUS,
                           posx + RADIUS, SQUARESIZE / 2 + RADIUS,
                           fill=RED, tags="preview_piece", extent=300, style=tk.PIESLICE)
    else:
        canvas.create_arc(posx - RADIUS, SQUARESIZE / 2 - RADIUS,
                           posx + RADIUS, SQUARESIZE / 2 + RADIUS,
                           fill=YELLOW, tags="preview_piece", extent=300, style=tk.PIESLICE)

def appeler_fonction_Player_Win():
    subprocess.run(["python", "Player_Win.py"])


def on_click(event):
    
"""
@brief Makes a move for the AI and updates the game state.
"""
    global board, game_over, turn, move_history  # Update to include move_history

    if not game_over and turn == PLAYER:
        col = event.x // SQUARESIZE

        # Check if the selected column is within bounds
        if 0 <= col < len(board[0]):
            if is_valid_location(board, col):
                row = get_next_open_row(board, col)

                # Added: Save the deep copy of the current state to the move history
                move_history.append(np.copy(board))

                drop_piece(board, row, col, PLAYER_PIECE)

                if winning_move(board, PLAYER_PIECE, WINDOW_LENGTH):
                    game_over = True
                    draw_board()
                    appeler_fonction_Player_Win()

                turn = AI
                draw_board()

                # Ask for AI Input
                if not game_over:
                    make_ai_move()
def undo_last_move():
    global board, game_over, turn, move_history

    if len(move_history) > 2:
        # Pop the last two states from the history
        

        # Restore the previous state
        board = np.copy(move_history[-1])

        game_over = False
        turn = PLAYER
        draw_board()




def appeler_fonction_Ordinateur_Win():
    subprocess.run(["python", "ORDINATEUR_Win.py"])

def restart_game():
    global board, game_over, turn  # Indicate that root is a global variable

    set_initial_turn()  # Set the initial turn based on starting player choice
    rows = int(row_scale.get())
    cols = int(col_scale.get())
    board = create_board(rows, cols)
    game_over = False
    draw_board()

    # Check the starting player and make the first move
    if turn == AI:
        make_ai_move()

def set_initial_turn():
    global turn
    if starting_player_var.get() == "Player":
        turn = PLAYER
    else:
        turn = AI

def make_ai_move():
    """
@brief Clears the selected column by removing all pieces in that column.
"""
    global board, game_over, turn  # Indicate that root is a global variable

    col, _ = minimax(board, depth_mapping.get(combo.get(), 3), -math.inf, math.inf, True)

    if is_valid_location(board, col):
        row = get_next_open_row(board, col)
        drop_piece(board, row, col, AI_PIECE)

        if winning_move(board, AI_PIECE, WINDOW_LENGTH):
            game_over = True
            draw_board()
            appeler_fonction_Ordinateur_Win()

        turn = PLAYER
        draw_board()

        if game_over:
            root.after(3000, root.destroy)  # Close the window after 3 seconds

player_clear_used = False
def clear_column():
    """
@brief Restarts the game by resetting the game state.
"""
    global board, game_over, turn, player_clear_used  # Indicate that root is a global variable

    if not game_over and turn == PLAYER and not player_clear_used:
        try:
            col = int(col_scale.get())  # Get the column number from the slider

            # Check if the selected column is within bounds
            if 0 <= col < len(board[0]):
                for r in range(len(board)):
                    board[r][col] = EMPTY

                draw_board()

                # Mark that the player has used the feature
                player_clear_used = True

                # Unbind the click event and enable the "Clear Column" button
                canvas.unbind("<Button-1>")
                clear_button.config(state=tk.NORMAL)

        except ValueError:
            # Handle the case where the user didn't input a valid integer
            print("Please enter a valid column number.")

def choose_column(valid_columns):
    # Create a simple dialog to choose a column
    top = tk.Toplevel(root)
    top.title("Choose Column")
    top.geometry("600x700")

    label = CTkLabel(top, text="Choose a column to clear:")
    label.pack(pady=20)

    var = tk.IntVar()

    # Create radio buttons for each valid column
    for col in valid_columns:
        CTkRadioButton(top, text=f"Column {col + 1}", variable=var, value=col).pack(pady=20)

    def on_ok():
        # Destroy the dialog and return the chosen column
        top.destroy()

    ok_button = CTkButton(top,corner_radius=32,fg_color="#C850C0",hover_color="#4158D0", text="OK", command=on_ok)
    ok_button.pack()

    # Set the dialog to be a modal window
    top.focus_set()
    top.grab_set()
    top.wait_window()

    return var.get() if var.get() in valid_columns else None

def clear_button_click():
    global board, game_over, turn, player_clear_used  # Indicate that root is a global variable

    if not game_over and turn == PLAYER and not player_clear_used:
        valid_columns = get_valid_locations(board)

        # Check if there are valid columns
        if valid_columns:
            # Display the list of columns and let the user choose
            column_choice = choose_column(valid_columns)

            # Check if the user chose a valid column
            if column_choice is not None:
                for r in range(len(board)):
                    board[r][column_choice] = EMPTY

                draw_board()

                # Mark that the player has used the feature
                player_clear_used = True

                # Rebind the click event and enable the "Clear Column" button
                canvas.bind("<Button-1>", on_click)
                clear_button.config(state=tk.NORMAL)

                # Ask for AI Input
                if not game_over:
                    make_ai_move()

# Initialize root after the functions
root = CTk()
root.title("OUTMAN & KHALIL Puissance 4")
root.configure(bg="#000000")
root.geometry("1900x1080")

SQUARESIZE = 100
RADIUS = SQUARESIZE // 2

# Create canvas after root
canvas = tk.Canvas(root, width=COLUMN_COUNT * SQUARESIZE, height=(ROW_COUNT + 1) * SQUARESIZE)
canvas.pack()

canvas.bind("<Motion>", on_motion)
canvas.bind("<Button-1>", on_click)

depth_mapping = {'Easy': 1, 'Medium': 3, 'Hard': 5, 'Legend': 6}

def on_depth_select(event):
    selected_depth = depth_mapping.get(combo.get(), 3)  # Default to 3 if not found
    print(f"Selected Depth: {selected_depth}")

def sliding(val):
    my_label_col.configure(text=int(value))

depth_label = CTkLabel(root, text="Select Level:", font=("Helvetica", 18))
depth_label.place(x=100, y=430)
combo = CTkComboBox(root, values=['Easy', 'Medium', 'Hard', 'Legend'])
combo.set('Medium')  # set default value
combo.place(x=100, y=470)
combo.bind("<<ComboboxSelected>>", on_depth_select)

row_label = CTkLabel(root, text="Select Rows:", font=("Helvetica", 18))
row_label.place(x=100, y=330)
row_scale = CTkSlider(master=root, from_=4, to=6, number_of_steps=2, width=300, height=20)
row_scale.set(6)  # set default value
row_scale.place(x=100, y=370)

col_label = CTkLabel(root, text="Select Columns:", font=("Helvetica", 18))
col_label.place(x=100, y=250)
col_scale = CTkSlider(master=root, from_=4, to=7, number_of_steps=3, width=300, height=20, command=sliding)
col_scale.set(7)  # set default value
col_scale.place(x=100, y=290)
my_label_col = CTkLabel(master=root, text="", font=("Helvetica", 18))
my_label_col.place(x=100, y=250)

# Add a label for the starting player selection
player_starting_label = CTkLabel(root, text="Select Starting Player:", font=("Helvetica", 18))
player_starting_label.place(x=100, y=190)

# Add a variable to store the starting player choice
starting_player_var = tk.StringVar()
starting_player_var.set("Player")  # Default starting player is the Player

# Add radio buttons for starting player selection
player_radio = CTkRadioButton(root, text="Player", variable=starting_player_var, value="Player", font=("Helvetica", 14))
player_radio.place(x=250, y=230)

ai_radio = CTkRadioButton(root, text="AI", variable=starting_player_var, value="AI", font=("Helvetica", 14))
ai_radio.place(x=350, y=230)

start_button = CTkButton(master=root, corner_radius=32, fg_color="#C850C0", hover_color="#4158D0",
                         font=("HALVETICA", 18), text="Start Game", command=restart_game)
start_button.place(x=100, y=70)

restart_button = CTkButton(master=root, corner_radius=32, fg_color="#C850C0", hover_color="#4158D0",
                           font=("HALVETICA", 18), text="Restart Game", command=restart_game)
restart_button.place(x=100, y=140)

#########################################################################
im5=Image.open("replay.png")

undo_button = CTkButton(master=root, corner_radius=10, fg_color="#C850C0", hover_color="#4158D0",
                        font=("HALVETICA", 14), text="Undo", image=CTkImage(dark_image=im5, light_image=im5), command=undo_last_move)
undo_button.place(x=800, y=600)

im6=Image.open("clear.jpeg")

clear_button = CTkButton(master=root, corner_radius=10, fg_color="#C850C0", hover_color="#4158D0",
                         font=("HALVETICA", 14), text="Clear Column",image=CTkImage(dark_image=im6, light_image=im6), command=clear_button_click)
clear_button.place(x=600, y=600)
# Set the initial turn based on starting player choice
set_initial_turn()

root.mainloop()